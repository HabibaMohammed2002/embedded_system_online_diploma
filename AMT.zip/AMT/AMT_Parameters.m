% AMT_Parameters.m
clear all; close all; clc;

% Basic vehicle and environment parameters
Af = 2.1;          % frontal area (m^2)
Cd = 0.7;          % coefficient of drag
mv = 1500;         % vehicle mass (kg)
rw = 0.32;         % tire radius (m)
row = 1.225;       % air density (kg/m^3)
fr = 0.025;        % rolling resistance coefficient
Grad = 0;          % gradient percentage (%)
theta = Grad*pi/180;    % gradient in radians

% Transmission parameters
eff = 95;          % transmission efficiency (%)
id = 4.5;          % final reduction ratio
ig1 = 4.25;        % first gear ratio
ig2 = 2.65;        % second gear ratio
ig3 = 1.65;        % third gear ratio
ig4 = 1;           % fourth gear ratio
gear_ratios = [ig1 ig2 ig3 ig4];

% Inertia parameters
Je = 0.159 + 0.0159;   % engine inertia (kg.m^2)
Jc = 0.5;          % clutch inertia (kg.m^2)
Jgb = 0.01;        % gearbox inertia (kg.m^2)
Jpt = 0.02;        % propeller shaft inertia (kg.m^2)

% Damping coefficients
Cc = 0.05;         % clutch damping (Nm/rad/s)
Cm = 0.012;        % main shaft damping (Nm/rad/s)
Cpt = 90;          % propeller shaft damping (N.m/rad/s)

% Stiffness parameters
Kc = 1182;         % clutch stiffness (N.m/rad)
Kpt = 6000;        % propeller shaft stiffness (N.m/rad)

% Calculated parameters
fa = 0.5*row*Cd*Af;    % air resistance factor (kg/m)
Fg = mv*9.81*sin(theta);    % gradient resistance (N)
Fr = fr*mv*9.81*cos(theta); % rolling resistance (N)
Jv = (mv*(rw^2)/(id^2)) + Jpt; % reduced vehicle inertia (kg.m^2)

mu=0.3;
Fn=1000;
Rm=0.1;
